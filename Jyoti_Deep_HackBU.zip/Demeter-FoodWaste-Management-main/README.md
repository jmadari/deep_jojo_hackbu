# ![20CS2409 - L 2 1  Demeter Logo (1) (1)](https://user-images.githubusercontent.com/76573095/170567093-9a54c224-4d1c-4dfe-97e6-4a36699da015.png)DEMETER (Work in Progress)



## The Food Waste Management App
```
-> Designed Primarily for the Pixel 2 (API 32)
    -> 5 inches
    -> Resolution - 1920*1080
```

### Login Activity&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  Signup Activity                                                  

<img width="334" alt="Screenshot 2022-05-25 at 5 09 34 PM" src="https://user-images.githubusercontent.com/76573095/170253621-3b69f35f-4233-4140-92dc-ca3ae7f31086.png">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <img width="342" alt="Screenshot 2022-05-26 at 3 39 39 PM" src="https://user-images.githubusercontent.com/76573095/170467326-30728178-fabd-4197-9cc4-ea2185b5c1eb.png">



### Settings Page &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  Profile Page

<img width="340" alt="Screenshot 2022-05-25 at 5 22 06 PM" src="https://user-images.githubusercontent.com/76573095/170255776-4191527e-74f5-4297-9e06-f9832db3cec5.png">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img width="342" alt="Screenshot 2022-05-26 at 3 42 00 PM" src="https://user-images.githubusercontent.com/76573095/170467723-c2273873-5298-47ff-8c5e-2afdc0285f81.png">

### Pop-up Form &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Available Item's Page

<img width="332" alt="Screenshot 2022-05-28 at 11 32 53 AM" src="https://user-images.githubusercontent.com/76573095/170812474-b6e7ec49-30f9-4667-a39e-d31be51a1fe6.png">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img width="332" alt="Screenshot 2022-05-28 at 11 34 01 AM" src="https://user-images.githubusercontent.com/76573095/170812511-b1aceb21-74f2-4a47-87c4-67861e619fe5.png">










